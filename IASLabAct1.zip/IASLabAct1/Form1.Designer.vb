﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        btnLogin = New Button()
        btnExit = New Button()
        Label1 = New Label()
        Label2 = New Label()
        txtUsername = New TextBox()
        txtPassword = New TextBox()
        MySqlCommand1 = New MySql.Data.MySqlClient.MySqlCommand()
        lbluser = New Label()
        lblpass = New Label()
        cbpass = New CheckBox()
        SuspendLayout()
        ' 
        ' btnLogin
        ' 
        btnLogin.Location = New Point(243, 185)
        btnLogin.Name = "btnLogin"
        btnLogin.Size = New Size(75, 23)
        btnLogin.TabIndex = 0
        btnLogin.Text = "Login"
        btnLogin.UseVisualStyleBackColor = True
        ' 
        ' btnExit
        ' 
        btnExit.Location = New Point(342, 185)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(75, 23)
        btnExit.TabIndex = 1
        btnExit.Text = "Exit"
        btnExit.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(204, 90)
        Label1.Name = "Label1"
        Label1.Size = New Size(63, 15)
        Label1.TabIndex = 2
        Label1.Text = "Username:"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(207, 138)
        Label2.Name = "Label2"
        Label2.Size = New Size(60, 15)
        Label2.TabIndex = 3
        Label2.Text = "Password:"
        ' 
        ' txtUsername
        ' 
        txtUsername.Location = New Point(276, 82)
        txtUsername.Name = "txtUsername"
        txtUsername.Size = New Size(152, 23)
        txtUsername.TabIndex = 4
        ' 
        ' txtPassword
        ' 
        txtPassword.Location = New Point(276, 130)
        txtPassword.Name = "txtPassword"
        txtPassword.Size = New Size(152, 23)
        txtPassword.TabIndex = 5
        ' 
        ' MySqlCommand1
        ' 
        MySqlCommand1.CacheAge = 0
        MySqlCommand1.Connection = Nothing
        MySqlCommand1.EnableCaching = False
        MySqlCommand1.Transaction = Nothing
        ' 
        ' lbluser
        ' 
        lbluser.AutoSize = True
        lbluser.Location = New Point(434, 85)
        lbluser.Name = "lbluser"
        lbluser.Size = New Size(0, 15)
        lbluser.TabIndex = 6
        ' 
        ' lblpass
        ' 
        lblpass.AutoSize = True
        lblpass.Location = New Point(434, 138)
        lblpass.Name = "lblpass"
        lblpass.Size = New Size(41, 15)
        lblpass.TabIndex = 7
        lblpass.Text = "Label4"
        ' 
        ' cbpass
        ' 
        cbpass.AutoSize = True
        cbpass.Location = New Point(434, 134)
        cbpass.Name = "cbpass"
        cbpass.Size = New Size(108, 19)
        cbpass.TabIndex = 8
        cbpass.Text = "Show Password"
        cbpass.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(688, 393)
        Controls.Add(cbpass)
        Controls.Add(lblpass)
        Controls.Add(lbluser)
        Controls.Add(txtPassword)
        Controls.Add(txtUsername)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(btnExit)
        Controls.Add(btnLogin)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btnLogin As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtUsername As TextBox
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents MySqlCommand1 As MySql.Data.MySqlClient.MySqlCommand
    Friend WithEvents lbluser As Label
    Friend WithEvents lblpass As Label
    Friend WithEvents cbpass As CheckBox

End Class

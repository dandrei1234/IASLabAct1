﻿Imports MySql.Data.MySqlClient
Imports System.Security.Cryptography
Imports System.Text
Public Class Form1
    Dim conn As New MySqlConnection("server=localhost; userid=root; password=root; database=user_authentication_db;")
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim query As String = "SELECT * FROM users_tbl WHERE username=@username AND password=@password AND status='1'"

        Try
            conn.Open()
            Dim cmd As New MySqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@username", txtUsername.Text)
            cmd.Parameters.AddWithValue("@password", (txtPassword.Text))

            Dim reader As MySqlDataReader = cmd.ExecuteReader()

            If reader.HasRows Then
                MessageBox.Show("Login Successful!")
                LoggedStatus = 0
                Me.Hide()
                Form2.Show()
            Else
                LoggedStatus += 1
                If LoggedStatus >= 3 Then
                    MessageBox.Show("Too many failed login attempts. The application will now close.", "Un-Authorize User!", MessageBoxButtons.OK, MessageBoxIcon.Stop)
                    Application.Exit()
                Else
                    MessageBox.Show($"Your account is still pending for activation.{Environment.NewLine}Attempts left: {3 - LoggedStatus}", "Access Denied!", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End If
            conn.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            If conn.State() = ConnectionState.Open Then conn.Close()
        End Try
    End Sub

    Private Sub txtPassword_TextChanged(sender As Object, e As EventArgs) Handles txtPassword.TextChanged
        txtPassword.UseSystemPasswordChar = True
        If Control.IsKeyLocked(Keys.CapsLock) Then
            lblpass.Text = "Caps Lock is ON"
            lblpass.ForeColor = Color.Black
        Else
            lblpass.Text = ""
        End If
    End Sub

    Private Sub txtUsername_TextChanged(sender As Object, e As EventArgs) Handles txtUsername.TextChanged
        If Control.IsKeyLocked(Keys.CapsLock) Then
            lbluser.Text = "Caps Lock is ON"
            lbluser.ForeColor = Color.Red
        Else
            lbluser.Text = ""
        End If
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles cbpass.CheckedChanged
        If cbpass.Checked Then
            txtPassword.UseSystemPasswordChar = False
        Else
            txtPassword.UseSystemPasswordChar = True
        End If
    End Sub
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
